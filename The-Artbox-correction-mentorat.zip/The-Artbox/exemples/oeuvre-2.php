<!doctype html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>The ArtBox</title>
</head>

<body>
    <header>
        <a href="index.html"><img src="img/logo.png" alt="Logo Artbox" id="logo"></a>
        <nav>
            <ul>
                <li><a href="index.html">Accueil</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <article id="detail-oeuvre">
            <div id="img-oeuvre">
                <img src="img/pawel-czerwinski-3.png" alt="Aashaaheen Baadal">
            </div>
            <div id="contenu-oeuvre">
                <h1>Aashaaheen Baadal</h1>
                <p class="description">Anaisha Devi</p>
                <p class="description-complete">
                    Sur cette oeuvre conceptuelle à la fois organique, minérale et liquide, Anaisha Devi nous transporte
                    dans un nuage noir envoûtant. Un sombre tableau qui, par son verni éclatant, rayonne tel un marbre
                    poli. Une oeuvre à la cohérence transcendantale, exécutée à la perfection
                </p>
            </div>
        </article>
    </main>
    <footer>
        <p>
            <strong>© THE ARTBOX</strong> - <em>Tous droits réservés</em>
        </p>
    </footer>
</body>

</html>