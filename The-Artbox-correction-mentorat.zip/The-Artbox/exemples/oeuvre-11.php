<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>The ArtBox</title>
</head>
<body>
<header>
    <a href="index.html"><img src="img/logo.png" alt="Logo Artbox" id="logo"></a>
    <nav>
        <ul>
            <li><a href="index.html">Accueil</a></li>
        </ul>
    </nav>
</header>
<main>
    <article id="detail-oeuvre">
        <div id="img-oeuvre">
            <img src="img/steve-johnson-2.png" alt="Asimilacion">
        </div>
        <div id="contenu-oeuvre">
            <h1>Asimilacion</h1>
            <p class="description">Angel Sanchez-Fernandez</p>
            <p class="description-complete">
                Mauris ut justo ac mi pretium eleifend. Curabitur sed magna ut elit facilisis pharetra. Maecenas tincidunt fermentum ipsum ut sollicitudin. Nullam feugiat, neque vel egestas sollicitudin, quam leo mattis mauris, in lacinia sem mi id risus. Nullam ultrices quam eu leo auctor tempus. Fusce vestibulum mi ex, vel ultricies purus mollis sollicitudin. Aenean ac vehicula ipsum. Nam turpis ante, ultrices eget odio sed, luctus bibendum mauris sodales sed.
            </p>
        </div>
    </article>
</main>
<footer>
    <p>
        <strong>© THE ARTBOX</strong> - <em>Tous droits réservés</em>
    </p>
</footer>
</body>
</html>