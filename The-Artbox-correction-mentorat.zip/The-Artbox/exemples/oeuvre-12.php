<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <title>The ArtBox</title>
</head>
<body>
<header>
    <a href="index.html"><img src="img/logo.png" alt="Logo Artbox" id="logo"></a>
    <nav>
        <ul>
            <li><a href="index.html">Accueil</a></li>
        </ul>
    </nav>
</header>
<main>
    <article id="detail-oeuvre">
        <div id="img-oeuvre">
            <img src="img/fly-d.png" alt="La Galaxia Gialla">
        </div>
        <div id="contenu-oeuvre">
            <h1>La Galaxia Gialla</h1>
            <p class="description">Eduardo Tancredi</p>
            <p class="description-complete">
                Mauris maximus, orci sollicitudin ultrices elementum, tellus neque feugiat leo, quis lobortis purus neque vel lectus. Ut sagittis eros id lectus porttitor tincidunt. Donec scelerisque diam nec felis egestas, eget finibus ante porttitor. Sed malesuada sapien ut semper accumsan. Duis tristique dui vel egestas porttitor. Nunc tristique dapibus orci a amet.
            </p>
        </div>
    </article>
</main>
<footer>
    <p>
        <strong>© THE ARTBOX</strong> - <em>Tous droits réservés</em>
    </p>
</footer>
</body>
</html>